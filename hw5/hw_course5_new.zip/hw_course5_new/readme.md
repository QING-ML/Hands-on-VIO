# 文件目录说明
- frontend 是前端
- backend 是后端
- utils 是工具
- notes 是笔记
有啥需要的随便加

### 编译说明：

```c++
cd BA_schur  \\ 进入文件夹
mkdir build   
cd build
cmake ..
make -j4    
```

